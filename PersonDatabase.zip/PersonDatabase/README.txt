Hello there user,

I have created a simple database for you to use. Please read the following instructions to start this application.
1) Open the Visual Studio IDE.
2) Open the solution to this project, "PersonDatabase.sln."
3) Clean the solution of this project.
4) Build a new solution of this project.
5) Run this application using the command "Debugging -> Start Without Debugging."

Below is a summary of the buttons with the application:
1) Clear - Clears all textboxes in the application.
2) Clear Data - Clears all data that have been entered into the database.
3) Submit - Adds a new person into the database.
4) View Data - Presents to you the data that has already been entered into the database.
5) Exit - Terminates your application.